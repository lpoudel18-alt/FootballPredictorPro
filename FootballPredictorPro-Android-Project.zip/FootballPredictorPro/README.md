# Football Predictor Pro — Android project

A private, local-first Android app source project implementing a full football forecasting workflow. The Android shell loads a local HTML/JavaScript interface inside WebView. Manual analysis works offline after installation; optional fixture import can use a football-data.org token.

## Included
- Android Studio project (Kotlin-free Java Activity + WebView assets)
- Manual expected-goals inputs, independent Poisson score probabilities, 1X2 / over 2.5 / BTTS, top exact scores
- Monte Carlo sampler with disclosed run count and inputs
- Full evidence checklist and quality gate
- Odds margin / expected-return calculations
- Local prediction history, actual result entry, basic accuracy and multiclass Brier score, CSV/report export
- Optional fixture fetch via football-data.org API

## Important model limitations
- Default expected-goal inputs are examples, not predictions based on current data. Edit them using verified evidence.
- Monte Carlo draws sample the same independent Poisson assumptions; they are not independent proof of predictive quality.
- Player markets and corners/cards/shots are not forecast without suitable data and a separate model.
- Calibration metrics are descriptive only and require recorded outcomes; robust validation requires an out-of-sample historical dataset.
- Provider API token is stored in WebView local storage in this prototype. Do not use sensitive credentials. Production deployment should use a secure backend proxy and server-side secrets.

## Build APK in Android Studio
1. Install Android Studio and Android SDK Platform 35 (or adjust `compileSdk` and `targetSdk` to an installed platform).
2. Open this folder (`FootballPredictorPro`) as a project and allow Gradle sync / dependency download.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Debug APK is normally produced at `app/build/outputs/apk/debug/app-debug.apk`.
5. For a release APK, configure signing in Android Studio. Keep private signing keys secure.

## Build environment status
This project generation environment did not have an Android SDK or Gradle executable detected, so APK compilation could not be run here. The source project is provided for compilation in Android Studio; this is not an APK file.
